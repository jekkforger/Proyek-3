let isFollowing = false;

function toggleFollow() {
  const followButton = document.querySelector('.follow-button');
  
  if (isFollowing) {
    followButton.textContent = 'Follow';
    followButton.classList.remove('following');
  } else {
    followButton.textContent = 'Following';
    followButton.classList.add('following');
  }
  
  isFollowing = !isFollowing;
}

const membersData = [
    { username: 'user1', profilePicture: 'profile1.jpg', isFollowing: false },
    { username: 'user2', profilePicture: 'profile2.jpg', isFollowing: false },
    // ... tambahkan anggota lainnya
  ];
  
  function toggleFollow(button, index) {
    if (membersData[index].isFollowing) {
      button.textContent = 'Follow';
      button.classList.remove('following');
      removeFromMyFriends(index);
    } else {
      button.textContent = 'Following';
      button.classList.add('following');
      addToMyFriends(index);
    }
    membersData[index].isFollowing = !membersData[index].isFollowing;
  }
  
  function addToMyFriends(index) {
    const friend = membersData[index];
    const myFriendsContainer = document.getElementById('my-friends');
  
    const profileDiv = document.createElement('div');
    profileDiv.className = 'profile';
  
    const usernameHeading = document.createElement('h2');
    usernameHeading.textContent = '@' + friend.username;
  
    const profileImg = document.createElement('img');
    profileImg.src = friend.profilePicture;
    profileImg.alt = 'Profile Picture';
  
    profileDiv.appendChild(usernameHeading);
    profileDiv.appendChild(profileImg);
  
    myFriendsContainer.appendChild(profileDiv);
  }
  
  function removeFromMyFriends(index) {
    const myFriendsContainer = document.getElementById('my-friends');
    const username = '@' + membersData[index].username;
  
    for (let i = 0; i < myFriendsContainer.children.length; i++) {
      const profileDiv = myFriendsContainer.children[i];
      if (profileDiv.querySelector('h2').textContent === username) {
        myFriendsContainer.removeChild(profileDiv);
        break;
      }
    }
  }
  
  document.addEventListener('DOMContentLoaded', function () {
    const allMembersContainer = document.getElementById('all-members');
  
    membersData.forEach((member, index) => {
      const profileDiv = document.createElement('div');
      profileDiv.className = 'profile';
  
      const usernameHeading = document.createElement('h2');
      usernameHeading.textContent = '@' + member.username;
  
      const profileImg = document.createElement('img');
      profileImg.src = member.profilePicture;
      profileImg.alt = 'Profile Picture';
  
      const followButton = document.createElement('button');
      followButton.className = 'follow-button';
      followButton.textContent = 'Follow';
      followButton.addEventListener('click', () => toggleFollow(followButton, index));
  
      profileDiv.appendChild(usernameHeading);
      profileDiv.appendChild(profileImg);
      profileDiv.appendChild(followButton);
  
      allMembersContainer.appendChild(profileDiv);
    });
  });
  